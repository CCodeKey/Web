package edu.ifpb.webII.model;


public interface AlunoDTO {
	
	String getNome();
	String getMatricula();

}
