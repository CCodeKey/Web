package edu.ifpb.webII;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuapWEBApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuapWEBApplication.class, args);
	}

}
