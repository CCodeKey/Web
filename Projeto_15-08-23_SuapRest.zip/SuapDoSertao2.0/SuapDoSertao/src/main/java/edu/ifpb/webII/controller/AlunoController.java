package edu.ifpb.webII.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.ifpb.webII.model.Aluno;
import edu.ifpb.webII.model.AlunoDTO;
import edu.ifpb.webII.model.Professor;
import edu.ifpb.webII.model.service.AlunoService;

@RestController
@RequestMapping("/alunos")
public class AlunoController {
	
	@Autowired
	private AlunoService alunoService;
	
	@GetMapping
	public List<Aluno> listarAlunos(){
		return alunoService.listarAlunos();
	}
	
	@PostMapping
	public Aluno cadastrarAluno(@RequestBody Aluno aluno) {
		return alunoService.cadastraAluno(aluno);
	}
	
	@PutMapping
	public Aluno atualizarAluno(@RequestBody Aluno aluno) {
		return alunoService.atualizarAluno(aluno);
	}
	
	@DeleteMapping
	public String deletarAluno(@RequestBody Aluno aluno) {
		return alunoService.deletarAluno(aluno);
	}
	
	@GetMapping
	@RequestMapping("/professorDTO")
	public List<AlunoDTO> listarAlunosAlunoDTOs(@RequestBody Professor professor){
		return alunoService.listarAlunosDTOProfessor(professor);
	}
	
	@GetMapping
	@RequestMapping("/professor")
	public List<Aluno> listarAlunosProfessor(@RequestBody Professor professor){
		return alunoService.listarAlunosProfessor(professor);
	}
}
