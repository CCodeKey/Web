//package edu.ifpb.webII.controller;
//
//public class profControl {
//	package edu.ifpb.webII.controller;
//
//	import java.util.List;
//
//	import org.springframework.beans.factory.annotation.Autowired;
//	import org.springframework.web.bind.annotation.DeleteMapping;
//	import org.springframework.web.bind.annotation.GetMapping;
//	import org.springframework.web.bind.annotation.PostMapping;
//	import org.springframework.web.bind.annotation.PutMapping;
//	import org.springframework.web.bind.annotation.RequestBody;
//	import org.springframework.web.bind.annotation.RequestMapping;
//	import org.springframework.web.bind.annotation.RestController;
//
//	import edu.ifpb.webII.model.Professor;
//	import edu.ifpb.webII.model.service.ProfessorService;
//
//	@RestController
//	@RequestMapping("/professores")
//	public class ProfessorController {
//		
//		@Autowired
//		private ProfessorService profesorService;
//		
//		@GetMapping
//		public List<Professor> listarCursos(){
//			return profesorService.listarProfessores();
//		}
//		
//		@PostMapping
//		public Professor cadastrarAluno(@RequestBody Professor professor) {
//			return profesorService.cadastrarProfessor(professor);
//		}
//		
//		@PutMapping
//		public Professor atualizarAluno(@RequestBody Professor professor) {
//			return profesorService.atualizarProfessor(professor);
//		}
//		
//		@DeleteMapping
//		public String deletarAluno(@RequestBody Professor professor) {
//			return profesorService.deletarProfessor(professor);
//		}
//		
//	}
//
//}
