package edu.ifpb.webII.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ifpb.webII.model.Aluno;
import edu.ifpb.webII.model.AlunoDTO;
import edu.ifpb.webII.model.Professor;
import edu.ifpb.webII.repository.AlunoRepository;


@Service
public class AlunoService {
	
	@Autowired
	private AlunoRepository alunorepository;
	
	public List<Aluno> listarAlunos(){
		return alunorepository.findAll();
	}
	
	public Aluno cadastraAluno(Aluno aluno) {
		return alunorepository.save(aluno);
	}
	
	public Aluno atualizarAluno(Aluno aluno) {
		return alunorepository.save(aluno);
	}
	
	public String deletarAluno(Aluno aluno) {
		Long matricula = aluno.getMatricula();
		alunorepository.deleteById(aluno.getMatricula());
		return "Aluno de matricula " + matricula + " deletado com sucesso";
	}
	
	public List<AlunoDTO> listarAlunosDTOProfessor(Professor professor){
		Long cod_professor = professor.getMatricula();
		return alunorepository.findAlunoDTOByProfessor(cod_professor);
	}
	public List<Aluno> listarAlunosProfessor(Professor professor){
		Long cod_professor = professor.getMatricula();
		return alunorepository.findAlunoByProfessor(cod_professor);
	}

}
