package edu.ifpb.webII.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import edu.ifpb.webII.model.Professor;
import edu.ifpb.webII.model.service.ProfessorService;

@Controller
@RequestMapping("/professores")
public class ProfessorController {
	
	@Autowired
	private ProfessorService professorService;
	
	@GetMapping("/cadastrar")
	public String cadastrar( Professor professor) {
		return "/professores/cadastro";
	}
	
	@PostMapping("/salvar")
	public String salvar(Professor professor, RedirectAttributes atr) {
		professorService.cadastrarProfessor(professor);
		atr.addFlashAttribute("sucesso", "Professor salvo com sucesso!");
		return "redirect:/professores/cadastrar";
	}
	
	@GetMapping("/listar")
	public String listar(ModelMap model) {
		List<Professor> professor = professorService.listarProfessores();
		model.addAttribute("professores",professor);
		return "/professores/lista";
	}
	
	
	@GetMapping("/editar/{codigo}")
	public String preEditar(@PathVariable("codigo") Long codigo, ModelMap model) {
		Professor professor = professorService.listarProfessor(codigo);
		model.addAttribute("professor", professor);
		return "/professores/cadastro";
	}
	

	@PostMapping("/editar")
	public String editar(Professor professor, RedirectAttributes atr) {
		professorService.atualizarProfessor(professor);
		atr.addFlashAttribute("sucesso", "Professor editado com sucesso!");
		return "redirect:/professores/cadastrar";
	}
	
	
	@GetMapping("excluir/{codigo}")
	public String excluir(@PathVariable("codigo") Long codigo, ModelMap model) {
		professorService.deletarProfessorporID(codigo);
		model.addAttribute("sucesso","Professor excluído com sucesso!");
		return listar(model);
	}
	
}
