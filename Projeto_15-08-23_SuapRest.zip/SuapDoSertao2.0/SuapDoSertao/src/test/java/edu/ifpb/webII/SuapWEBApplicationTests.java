package edu.ifpb.webII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuapWEBApplicationTests {

	@Test
	void contextLoads() {
	}

}
