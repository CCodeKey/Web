package ifpb.web.rest.model.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import ifpb.web.rest.model.Cliente;
import ifpb.web.rest.model.Funcionario;
import ifpb.web.rest.model.repository.FuncionarioRepository;

@Service
public class FuncionarioService {

	@Autowired
	private FuncionarioRepository funcionarioRepository;

	public List<Funcionario> listagem() {
		return funcionarioRepository.findAll();
	}

	public Funcionario listar(Funcionario funcionario) {
		return funcionarioRepository.findById(funcionario.getMatricula()).get();
	}

	public Funcionario novo(Funcionario funcionario) {
		return funcionarioRepository.save(funcionario);
	}

	public Funcionario atualizar(Funcionario funcionario) {
		return funcionarioRepository.save(funcionario);
	}

	public Long deletar(Funcionario funcionario) {
		funcionarioRepository.deleteById(funcionario.getMatricula());
		return (long) 0;
	}
}
